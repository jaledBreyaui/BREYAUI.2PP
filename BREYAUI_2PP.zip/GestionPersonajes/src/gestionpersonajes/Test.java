package gestionpersonajes;

import config.AppConstants;
import java.io.IOException;
import modelo.Clase;
import modelo.Inventario;
import modelo.Personaje;

public class Test {

    public static void main(String[] args) {
        try {
            Inventario<Personaje> inventarioPersonajes = new Inventario<>();
            inventarioPersonajes.agregar(new Personaje(1, "Aragorn", Clase.GUERRERO, 20));
            inventarioPersonajes.agregar(new Personaje(2, "Gandalf", Clase.MAGO, 50));
            inventarioPersonajes.agregar(new Personaje(3, "Legolas", Clase.ARQUERO, 25));
            inventarioPersonajes.agregar(new Personaje(4, "Frodo", Clase.GUERRERO, 10));
            inventarioPersonajes.agregar(new Personaje(5, "Saruman", Clase.MAGO, 40));
            inventarioPersonajes.agregar(new Personaje(6, "Robin Hood", Clase.ARQUERO, 30));

            inventarioPersonajes.paraCadaElemento(personaje
                    -> System.out.println(personaje));

            //ORDEN NATURAL
            System.out.println("\nPersonajes ordenados por nombre (orden natural):");
            inventarioPersonajes.ordenarContenido();
            inventarioPersonajes.paraCadaElemento(personaje
                    -> System.out.println(personaje));

            //ORDENADOS POR NIVEL
            System.out.println("\nPersonajes ordenados por nivel (orden natural):");
            inventarioPersonajes.ordenarContenido((p1, p2) -> Integer.compare(p2.getNivel(), p1.getNivel()));
            inventarioPersonajes.paraCadaElemento(personaje
                    -> System.out.println(personaje));

            //FILTRAR
            // Filtrar personajes de clase MAGO
            System.out.println("\nPersonajes de la clase MAGO:");
            inventarioPersonajes.filtrar(p -> p.getClasePersonaje().equals(Clase.MAGO))
                    .forEach(personaje -> System.out.println(personaje));

            // TRANSFORMAR
            System.out.println("\nAumentando nivel de todos los personajes en +5:");
            inventarioPersonajes.transformar(p -> {
                p.subirNivel(5);
                return p;
            });
            inventarioPersonajes.paraCadaElemento(personaje
                    -> System.out.println(personaje));

            // Guardar el inventario en un archivo binario
            inventarioPersonajes.guardarEnArchivo(AppConstants.PATH_SERIAL);

            // Cargar el inventario desde el archivo binario
            Inventario<Personaje> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo(AppConstants.PATH_SERIAL);
            System.out.println("\nPersonajes cargados desde archivo binario:");
            inventarioCargado.paraCadaElemento(personaje
                    -> System.out.println(personaje));

            // Guardar el inventario en un archivo CSV
            inventarioPersonajes.guardarEnCSV(AppConstants.PATH_CSV);

            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV(AppConstants.PATH_CSV, item -> inventarioCargado.eliminar(0));
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(personaje
                    -> System.out.println(personaje));

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }

    }
}
