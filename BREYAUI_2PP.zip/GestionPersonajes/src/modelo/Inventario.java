package modelo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicio.Archivador;
import servicio.Serializador;

public class Inventario<T> implements Inventariable<T>, Iterable<T> {

    List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("Valor nulo");
        }
        if (!estaRepetido(item)) {
            items.add(item);
            System.out.println("Se agrego  el contenido al inventario!");
        }
    }

    private boolean estaRepetido(T item) {
        if (items.contains(item)) {
            throw new ItemRepetidoException();
        }
        return false;
    }

    @Override
    public T obtener(int i) {
        validarIndice(i);
        return items.get(i);
    }

    @Override
    public void eliminar(int i) {
        if (i >= 0 && i < items.size()) {
            items.remove(i);
        } else {
            System.out.println("Indice fuera de rango!");
        }
    }

    private void validarIndice(int indice) {

        if (!(indice > 0 && indice < items.size())) {
            throw new IndexOutOfBoundsException("Indice fuera de rango!");
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                aux.add(item);
            }
        }
        return aux;
    }

    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> aux = new ArrayList<>();
        for (T item : items) {
            aux.add(transformacion.apply(item));
        }
        return aux;

    }

    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        items.sort(comparador);
        return items.iterator();
    }

    @Override
    public void ordenarContenido(Comparator<? super T> comparador) {
        iterator(comparador);
    }

    @Override
    public void ordenarContenido() {
        ordenarContenido((Comparator<? super T>) (Comparator.naturalOrder()));
    }

    public void paraCadaElemento(Consumer<? super T> tarea) {
        for (T item : items) {
            tarea.accept(item);
        }
    }

    //ARCHIVOS
    public void guardarEnArchivo(String path) {
        List<CSVSerializable> itemsSerializables = new ArrayList<>();

        for (T item : items) {
            if (item instanceof CSVSerializable serializableItem) {
                itemsSerializables.add(serializableItem);
            }
        }
        if (!itemsSerializables.isEmpty()) {
            Serializador.serializarPersonajes(itemsSerializables, path);
        } else {
            System.out.println("No hay elementos para serializar");
        }
    }

    public List<Personaje> cargarDesdeArchivo(String path) {
        List<Personaje> personajes = Serializador.deserializarPersonajes(path);

        if (personajes == null || personajes.isEmpty()) {
            System.out.println("No hay personajes en este archivo");
            personajes = new ArrayList<>();
        } else {
            System.out.println("Personajes cargados!");
            for (Personaje p : personajes) {
                this.agregar((T) p);
            }
        }
        return personajes;
    }

    public void guardarEnCSV(String path) {
        List<CSVSerializable> itemsSerializables = new ArrayList<>();

        for (T item : items) {
            if (item instanceof CSVSerializable serializableItem) {
                itemsSerializables.add(serializableItem);
            }
        }
        if (!itemsSerializables.isEmpty()) {
            Archivador.guardarPersonajesCSV(itemsSerializables, path);
            System.out.println("Cargado a CSV");
        } else {
            System.out.println("No hay nada para pasar a CSV");
        }
    }

    public List<Personaje> cargarDesdeCSV(String path, Consumer<? super T> tarea) {
        List<Personaje> personajes = Archivador.cargarPersonajeCSV(path);

        if (personajes == null || personajes.isEmpty()) {
            System.out.println("\n No hay personajes");
            personajes = new ArrayList<>();
        } else {
            if (!items.isEmpty()) {
                System.out.println("HOLA");
                List<T> itemsCopia = new ArrayList<>(items);

                for (T item : itemsCopia) {
                    tarea.accept(item);
                }
                for (Personaje p : personajes) {
                    this.agregar((T) p);

                }
            }
        }
        return personajes;
    }
}
