

package modelo;


public class Personaje implements Comparable<Personaje>, CSVSerializable {
    private static final Long seriaVersionUID = 1L;
    private int id;
    private String nombre;
    private Clase clasePersonaje;
    private int nivel;

    public Personaje(int id, String nombre, Clase clasePersonaje, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clasePersonaje = clasePersonaje;
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return  "ID: " + id + ", Nombre: " + nombre + ", Clase: " + clasePersonaje + ", Nivel: " + nivel + '}';
    }

    @Override
    public int compareTo(Personaje p) {
        return nombre.compareTo(p.nombre);
    }

    public int getNivel() {
        return nivel;
    }

    public Clase getClasePersonaje() {
        return clasePersonaje;
    }
    
    public void subirNivel(int puntos){
        if(puntos <= 0 ){
            throw new IllegalArgumentException("Este metodo es para Subir el nivel");
        }
        nivel = nivel + puntos;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clasePersonaje +"," + nivel;
    }
    
    public static Personaje fromCSV(String path){
        Personaje toReturn = null;
        
        String[] values = path.split(",");
                if (values.length == 4) {
                    int id = Integer.parseInt(values[0]);
                    String nombre = values[1];
                    Clase clase = Clase.valueOf(values[2]);
                    int nivel = Integer.parseInt(values[3]);
                    
                    toReturn = new Personaje(id, nombre, clase, nivel);
        }
        return toReturn;
    }
    
}
