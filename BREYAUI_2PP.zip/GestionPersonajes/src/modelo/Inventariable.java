package modelo;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Inventariable<T> {

    void agregar(T item);

    T obtener(int i);

    void eliminar(int i);

    List<T> filtrar(Predicate<? super T> criterio);

    void ordenarContenido();

    void ordenarContenido(Comparator<? super T> comparador);

    List<T> transformar(Function<? super T, ? extends T> transformacion);

}
