

package modelo;


public class ItemRepetidoException extends RuntimeException{
    private static final String MESSAGE = "Este item ya se encuentra en la lista";

    public ItemRepetidoException() {
        super(MESSAGE);
    }
    
    
}
