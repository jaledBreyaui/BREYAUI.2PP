package modelo;

import java.io.Serializable;

@FunctionalInterface
public interface CSVSerializable extends Serializable {

    String toCSV();

}
